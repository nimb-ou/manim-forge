"""Teacher-model client for synthetic data generation.

A large model writes training examples; the small local model learns from them.
That is distillation, and it directly attacks this project's weakest link — the
public corpus is only ~3.7k rows and much of it is poor.

Provider-agnostic by design. Gemini, DeepSeek and OpenAI all expose an
OpenAI-compatible endpoint, so switching teacher is a base URL, not a rewrite.
Start on Gemini's free tier (1,500 requests/day, permanent) and only pay for
volume once the prompt is proven to produce data that survives the gate.

Nothing generated here is trusted. Every scene goes through the same render
gate as the scraped corpus, so a teacher that hallucinates simply produces rows
that get dropped.
"""

from __future__ import annotations

import os
import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv() -> None:
    """Read .env if present. Keys live there, never in the repo — .env is
    gitignored, so a key can't be committed by accident.

    Last occurrence wins, and it overrides the existing environment. Both
    matter: setdefault silently preferred a stale exported key over the correct
    one in .env, which presents as "API key not valid" for a key that is
    perfectly valid — as curl against the same file proved.
    """
    env = Path(".env")
    if not env.exists():
        return
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip("'\"")
        if v:
            os.environ[k.strip()] = v


_load_dotenv()

#: Gemini uses Google's native SDK, not the OpenAI-compatible endpoint.
#: Google migrated API keys from "Standard keys" (AIza..., rejected outright
#: since September 2026) to "Auth keys" (AQ.Ab...), and the compatibility
#: endpoint still assumes the old format — so a perfectly valid new key is
#: refused there with "Please pass a valid API key". The native SDK accepts it.
GEMINI_REST = "https://generativelanguage.googleapis.com/v1beta"

#: Rate limits are per-model, so rotating across models multiplies the usable
#: free quota. Probed against a real free-tier key: the newest models
#: (3.8-flash, the Pro tier, and the *-latest aliases pointing at them) return
#: 429 immediately, while these serve reliably. Strongest first — the rotation
#: falls back down the list rather than round-robining blindly, so most
#: generations come from the best model that will answer.
#: Per-model memo of whether thinkingConfig is accepted. Populated by the
#: first 400, so each model is probed at most once per process.
_THINKING_OK: dict[str, bool] = {}

#: Models to rotate across, newest first. Rate limits are per model, so the
#: rotation reaches the daily ceiling sooner; it does not raise it.
#:
#: Checked against the live model list rather than remembered: gemini-2.5-flash
#: and gemini-2.5-flash-lite now 404, and gemini-3.8-flash and
#: gemini-3-flash-preview had been missing from this list entirely. A stale
#: entry costs a retry cycle per call, every call.
GEMINI_ROTATION = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3-flash-preview",
    "gemini-flash-latest",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3.1-flash-lite-preview",
    "gemini-flash-lite-latest",
]

#: Guards the module-global SYSTEM swap the Gemini path still needs.
_SYSTEM_LOCK = threading.Lock()

PROVIDERS = {
    "gemini": {
        "native": True,
        "key_env": "GEMINI_API_KEY",
        "model": "gemini-flash-latest",
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com/v1",
        "key_env": "DEEPSEEK_API_KEY",
        "model": "deepseek-chat",
    },
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "key_env": "OPENAI_API_KEY",
        "model": "gpt-4o-mini",
    },
    # Every entry below speaks the OpenAI chat format, so they cost nothing to
    # add beyond a base URL. They exist because Gemini's free tier is roughly
    # 944 calls a day in practice and runs out by mid-afternoon, leaving the
    # code daemon parked for ten hours. Teacher diversity is also worth having
    # on its own: a corpus written entirely by one model inherits that model's
    # habits, including its mistakes.
    "mistral": {
        "base_url": "https://api.mistral.ai/v1",
        "key_env": "MISTRAL_API_KEY",
        "model": "codestral-latest",
        "rotation": ["codestral-latest", "mistral-large-latest",
                     "mistral-medium-latest", "mistral-small-latest"],
    },
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "key_env": "GROQ_API_KEY",
        "model": "openai/gpt-oss-120b",
        "rotation": ["openai/gpt-oss-120b", "qwen/qwen3.8-27b",
                     "openai/gpt-oss-20b"],
    },
    "cerebras": {
        "base_url": "https://api.cerebras.ai/v1",
        "key_env": "CEREBRAS_API_KEY",
        "model": "llama-3.3-70b",
    },
    "together": {
        "base_url": "https://api.together.xyz/v1",
        "key_env": "TOGETHER_API_KEY",
        "model": "Qwen/Qwen2.5-Coder-32B-Instruct",
    },
}


def pool_entries(providers: list[str] | None = None) -> list[str]:
    """Every (provider, model) worth rotating through, as "provider:model".

    The daemons hold one flat rotation rather than one per provider, because
    what they need at any moment is simply *something that will answer*. Split
    on the first colon: model names contain slashes and dots, never colons.

    Ordering interleaves providers instead of listing each in turn, so a
    round-robin cursor spreads load across providers rather than draining one
    quota before touching the next.
    """
    names = providers if providers is not None else available_providers()
    per: list[list[str]] = []
    for name in names:
        cfg = PROVIDERS[name]
        if name == "gemini":
            models = list(GEMINI_ROTATION)
        else:
            models = cfg.get("rotation") or [cfg["model"]]
        per.append([f"{name}:{m}" for m in models])
    out: list[str] = []
    for i in range(max((len(x) for x in per), default=0)):
        for group in per:
            if i < len(group):
                out.append(group[i])
    return out


def teacher_for(entry: str, **kw) -> "Teacher":
    """Build a Teacher from a "provider:model" pool entry."""
    provider, _, model = entry.partition(":")
    return Teacher(provider=provider, model=model, **kw)


def available_providers() -> list[str]:
    """Providers whose key is actually present in the environment.

    Used by the daemons to spread work across everything configured rather
    than hammering one quota to exhaustion and then idling. Reads .env the
    same way the Teacher does, so it agrees with what a Teacher would find.
    """
    _load_dotenv()
    return [name for name, cfg in PROVIDERS.items()
            if os.environ.get(cfg["key_env"])]

# The teacher is shown our beat format by example rather than described it —
# few-shot works far better than specification for an API it has never seen.
FEWSHOT = '''from manim import *
from forge.beats import ForgeScene, beat
from forge.primitives.grid import Board, Cell

class RookReach(ForgeScene):
    board = Board(8, 8)

    def xy(self, cell):
        x = -3.1 + (cell.col - 3.5) * 0.7
        y = (cell.row - 3.5) * 0.7 - 0.3
        return np.array([x, y, 0.0])

    @beat("Draw an 8x8 chessboard", seconds=3)
    def draw_board(self):
        self.squares = VGroup(*[
            Square(side_length=0.7, stroke_width=0, fill_opacity=1,
                   fill_color="#3D4852" if self.board.is_light(c) else "#2A313A"
                   ).move_to(self.xy(c))
            for c in self.board.cells()])
        self.play(LaggedStart(*[FadeIn(s, scale=0.6) for s in self.squares],
                              lag_ratio=0.012, run_time=2.0))

    @beat("Count the squares a rook reaches", seconds=4)
    def reach(self):
        moves = self.board.rook_moves(Cell(3, 3))        # computed, not recalled
        tiles = VGroup(*[Square(side_length=0.7, stroke_width=0, fill_opacity=0.42,
                                fill_color=YELLOW_C).move_to(self.xy(c)) for c in moves])
        label = Text(f"{len(moves)} squares", font_size=40, color=YELLOW_C).move_to([3.4, 0.6, 0])
        self.play(LaggedStart(*[FadeIn(t) for t in tiles], lag_ratio=0.05, run_time=1.6))
        self.play(Write(label), run_time=0.6)
        self.wait(0.4)
'''

SYSTEM = f"""You write 3Blue1Brown-style mathematical animations using Manim Community Edition v0.19+.

You write scenes in a BEAT format. A beat is one communicative step lasting
2-5 seconds: something appears, transforms, or gets annotated. Beats are
methods on a ForgeScene subclass, decorated with @beat("intent", seconds=N),
and they run in the order written. Mobjects assigned to `self` persist across
beats.

Here is a complete example of the format:

```python
{FEWSHOT}```

RULES, all of which matter:
1. Subclass ForgeScene, not Scene. Use @beat on every method.
   For a 3D topic subclass BOTH: `class X(ForgeScene, ThreeDScene)`, then
   `self.set_camera_orientation(phi=..., theta=...)` inside the first beat.
2. EVERY beat must animate with self.play(...). Never write a beat that only
   calls self.add() - it renders no video.
3. Any number shown on screen must be COMPUTED in the code, never hardcoded
   from memory. Use len(), sum(), Fraction, or a loop. If you claim a
   probability is 1/16, derive it by counting.
4. Use exact values. Fraction(1,16), not 0.0625.
5. Keep objects inside the frame: x in [-7, 7], y in [-4, 4]. Put a board or
   diagram on the left and labels on the right rather than stacking them.
6. Use only real Manim CE names. Do not invent classes or keyword arguments.
7. Give each beat a `narration=` argument: one or two sentences of what a
   narrator would say over it, in plain spoken English. This is what makes an
   explainer rather than a diagram, so write it as if talking to someone.
8. Output ONLY one ```python code block. No explanation before or after."""


def user_prompt(topic: str, n_beats: int, length_hint: str) -> str:
    return (
        f"Write a beat-structured Manim scene explaining:\n\n  {topic}\n\n"
        f"Use about {n_beats} beats ({length_hint}).\n"
        f"Give the class a descriptive name. Make it visually clear and "
        f"genuinely explanatory, not just decorative."
    )


_FENCE = re.compile(r"```(?:python)?\s*\n(.*?)```", re.S)


_OPEN_FENCE = re.compile(r"^\s*```(?:python)?\s*\n", re.M)


def extract_code(text: str) -> str:
    """Pull code out of a model response, closed fence or not.

    A generation that hits the token limit is truncated mid-block, so the
    closing fence never arrives. Requiring one meant the opening ```python line
    was returned as if it were code, and every such row died with a syntax
    error on line 1.
    """
    text = text or ""
    blocks = _FENCE.findall(text)
    if blocks:
        return max(blocks, key=len).strip()
    m = _OPEN_FENCE.search(text)
    if m:
        return text[m.end():].strip().removesuffix("```").strip()
    return text.strip()


@dataclass
class Teacher:
    provider: str = "gemini"
    model: str | None = None
    temperature: float = 0.7      # some diversity: identical scenes teach nothing
    last_model_used: str = ""
    last_finish_reason: str = ""
    last_usage: dict | None = None

    def __post_init__(self):
        cfg = PROVIDERS[self.provider]
        key = os.environ.get(cfg["key_env"])
        if not key:
            raise RuntimeError(
                f"Set {cfg['key_env']} in your environment or .env file.")
        self.model = self.model or cfg["model"]
        self.native = cfg.get("native", False)
        if self.native:
            # Raw REST rather than the google-genai SDK. Google's new "Auth
            # keys" (AQ.Ab...) are rejected by both the OpenAI-compatibility
            # endpoint and the current SDK, while the REST endpoint accepts
            # them without complaint. One less dependency, and it demonstrably
            # works.
            self._key = key
            self._client = None
        else:
            from openai import OpenAI
            self._client = OpenAI(api_key=key, base_url=cfg["base_url"])

    def _gemini_rest(self, user: str, max_tokens: int, attempts: int = 5) -> str:
        """Try each model in the rotation before giving up.

        A 429 means *this model* is exhausted, not that the key is. Moving to
        the next model recovers immediately where sleeping would waste a minute
        and then fail anyway.
        """
        import json as _json
        import time as _time
        import urllib.error
        import urllib.request
        # maxOutputTokens is generous and thinking is switched off. On the
        # 3.x models internal reasoning is billed against the same output
        # budget, so a nominally ample limit silently truncates the code —
        # which surfaces downstream as a syntax error and reads as a bad
        # generation rather than a bad budget. thinkingConfig is ignored by
        # models that do not support it, so sending it is always safe.
        def _body(with_thinking_off: bool) -> bytes:
            cfg = {"temperature": self.temperature, "maxOutputTokens": max_tokens}
            if with_thinking_off:
                cfg["thinkingConfig"] = {"thinkingBudget": 0}
            return _json.dumps({
                "contents": [{"role": "user", "parts": [{"text": user}]}],
                "systemInstruction": {"parts": [{"text": SYSTEM}]},
                "generationConfig": cfg,
            }).encode()

        # Switching thinking off keeps internal reasoning from eating the output
        # budget and truncating code mid-function. But support is uneven: the
        # lite models accept thinkingBudget and 3.6-flash rejects the whole
        # request with a 400. So it is attempted and dropped per model, and the
        # result cached — a capability discovered once, not guessed.
        body = _body(_THINKING_OK.get(self.model, True))
        # 503 (overloaded) and 429 (rate limited) are routine on a free tier
        # and are not failures — they mean "try again shortly", or better,
        # "ask a different model".
        models = [self.model] + [m for m in GEMINI_ROTATION if m != self.model] \
            if self.provider == "gemini" else [self.model]

        last = None
        data = None
        for attempt in range(attempts):
            for m in models:
                body = _body(_THINKING_OK.get(m, True))
                req = urllib.request.Request(
                    f"{GEMINI_REST}/models/{m}:generateContent",
                    data=body, headers={"x-goog-api-key": self._key,
                                        "Content-Type": "application/json"})
                try:
                    data = _json.load(urllib.request.urlopen(req, timeout=240))
                    self.last_model_used = m
                    break
                except urllib.error.HTTPError as e:
                    last = e
                    if e.code == 400 and _THINKING_OK.get(m, True):
                        # This model does not accept thinkingConfig. Remember
                        # that and retry it once without.
                        _THINKING_OK[m] = False
                        try:
                            retry = urllib.request.Request(
                                f"{GEMINI_REST}/models/{m}:generateContent",
                                data=_body(False),
                                headers={"x-goog-api-key": self._key,
                                         "Content-Type": "application/json"})
                            data = _json.load(urllib.request.urlopen(retry, timeout=240))
                            self.last_model_used = m
                            break
                        except urllib.error.HTTPError as e2:
                            last = e2
                            continue
                    if e.code not in (429, 500, 502, 503, 504):
                        raise
            if data is not None:
                break
            _time.sleep(min(2 ** attempt * 3, 60))
        if data is None:
            raise last
        cands = data.get("candidates") or []
        if not cands:
            return ""
        cand = cands[0]
        self.last_finish_reason = cand.get("finishReason", "")
        usage = data.get("usageMetadata", {})
        self.last_usage = {
            "output": usage.get("candidatesTokenCount"),
            "thoughts": usage.get("thoughtsTokenCount"),
        }
        parts = cand.get("content", {}).get("parts") or []
        return "".join(p.get("text", "") for p in parts)

    @classmethod
    def list_models(cls, provider: str = "gemini") -> list[str]:
        """What this API key can actually reach.

        Chat product names and API model ids drift apart, so ask the endpoint
        rather than guessing from what the web UI offers.
        """
        cfg = PROVIDERS[provider]
        key = os.environ.get(cfg["key_env"])
        if not key:
            raise RuntimeError(f"Set {cfg['key_env']} first.")
        if cfg.get("native"):
            import json as _json
            import urllib.request
            req = urllib.request.Request(
                f"{GEMINI_REST}/models?pageSize=200",
                headers={"x-goog-api-key": key})
            data = _json.load(urllib.request.urlopen(req, timeout=60))
            return sorted(
                m["name"].removeprefix("models/") for m in data.get("models", [])
                if "generateContent" in m.get("supportedGenerationMethods", [])
            )
        from openai import OpenAI
        client = OpenAI(api_key=key, base_url=cfg["base_url"])
        return sorted(m.id for m in client.models.list())

    def ask(self, user: str, max_tokens: int = 3000,
            system: str | None = None, attempts: int = 1) -> str:
        """Raw completion, whichever provider this Teacher is for.

        Exists because callers that are not generating scene code -- the prose
        tasks, mainly -- were reaching into ``_gemini_rest`` directly, which
        silently restricted them to one provider. Passing ``system`` here also
        replaces the module-global swap those callers were doing, which was
        not thread-safe: two workers wanting different system prompts would
        race, and the loser would get the other's.
        """
        # attempts=1 by default, deliberately. Retrying inside the call takes
        # minutes on an exhausted Gemini key, and every second of that is a
        # worker not trying the provider that *would* have answered. The
        # caller's ModelPool already retires and rotates; that is its job, and
        # it cannot do it while this method is still sleeping.
        if self.native:
            if system is None:
                return self._gemini_rest(user, max_tokens, attempts=attempts)
            import forge.synth.teacher as _self
            with _SYSTEM_LOCK:
                original = _self.SYSTEM
                _self.SYSTEM = system
                try:
                    return self._gemini_rest(user, max_tokens, attempts=attempts)
                finally:
                    _self.SYSTEM = original
        return self._openai_chat(system or SYSTEM, user, max_tokens,
                                 attempts=attempts)

    def generate(self, topic: str, n_beats: int, length_hint: str,
                 max_tokens: int = 16000) -> str:
        user = user_prompt(topic, n_beats, length_hint)
        if self.native:
            return extract_code(self._gemini_rest(user, max_tokens))
        return extract_code(self._openai_chat(SYSTEM, user, max_tokens))

    def _openai_chat(self, system: str, user: str, max_tokens: int,
                     attempts: int = 4) -> str:
        """One chat completion, rotating models on a rate limit.

        Same shape as the Gemini path: a 429 is about this minute and this
        model, never about the request, so it moves to the next model rather
        than surfacing an error the caller would treat as a failed job.
        """
        cfg = PROVIDERS[self.provider]
        models = [self.model] + [m for m in cfg.get("rotation", [])
                                 if m != self.model]
        last = None
        for attempt in range(attempts):
            for m in models:
                try:
                    r = self._client.chat.completions.create(
                        model=m,
                        messages=[{"role": "system", "content": system},
                                  {"role": "user", "content": user}],
                        temperature=self.temperature,
                        max_tokens=max_tokens,
                    )
                    self.last_model_used = m
                    self.last_finish_reason = r.choices[0].finish_reason
                    return r.choices[0].message.content or ""
                except Exception as e:  # noqa: BLE001 - provider SDKs vary
                    last = e
                    if not any(t in str(e) for t in ("429", "rate", "capacity",
                                                     "503", "overloaded")):
                        raise
            time.sleep(min(2 ** attempt, 20))
        raise RuntimeError(f"{self.provider}: all models rate-limited ({last})")


#: Prompt wrapper for turning a passage of 3Blue1Brown narration into a scene.
#: Shared by the one-shot script and the continuous daemon, so it lives here
#: rather than in a script — `scripts/` is not an importable package.
NARRATION_INSTRUCTION = """Below is a passage of narration from a mathematics video.

Write the Manim scene that should be on screen while this is being said.
Follow every rule you were given about beats, computed values and layout.
Set each beat's narration= to the part of the passage it covers.

If the passage cannot sensibly be animated — it is an aside, a sponsor
message, a reference to another video, or pure commentary with no visual
content — reply with exactly SKIP and nothing else.

PASSAGE:
"""
